'use strict'

var app = angular.module('myApp', []);





app.controller('myController',['$scope','UserService',function($scope,UserService) {
	$scope.requirement= {description:'',
			prerequisite:'',
			priority:'',
			shortTitle:'',
			status:'',
			title:'',
			type:'',
			version:'',
			attachment:'',
			elaboration:'',
			links:''};
	$scope.requirements=[];
	//fetchAllRequirements();

	function fetchAllRequirements(){
		alert('controller');

	}
	$scope.deleteRequirement= function()
	{
		alert("deleteRequirement controller");
		UserService.deleteRequirement($scope.requirement).then(fetchAllRequirements, function(reason) {
			console.error("failed to delete");
		})

	}

	$scope.createRequirement= function()
	{
		alert("create requirement controller");
		UserService.createRequirement($scope.requirement).then(fetchAllRequirements, function(reason) {
			console.error("failed to create");
		})

	}
	

}])
