package com.cybage.project.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.cybage.project.dao.RequirementDao;
import com.cybage.project.model.DtoToPojoConverter;
import com.cybage.project.model.Requirement;
import com.cybage.project.model.RequirementDTO;
import com.cybage.project.model.RequirementElaboration;




@Service
@Transactional 
public class RequirementServiceImpl implements RequirementService {

	@Autowired
	private RequirementDao requirementDao;

	@Autowired
	private DtoToPojoConverter dtoToPojoConverter;


	@Override
	public Integer saveRequirement(RequirementDTO dto) {

		int requirementId=requirementDao.saveRequirement(dtoToPojoConverter.toRequirement(dto));

		return requirementId;
	}


	@Override
	public List<Requirement> getAllRequirements() {
		List<Requirement> requirements= requirementDao.getAllRequirements();
		/*for (Requirement requirement : requirements) {
			System.out.println(requirement);
		}*/
		return requirements;
	}


}
