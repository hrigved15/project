var mainApp = angular.module("myApp", ['ngRoute']);
mainApp.config(['$routeProvider',
  function($routeProvider) {
    $routeProvider.
    when('/createRequirement', {
      templateUrl: 'static/views/createRequirement.html',
     
    }).
    when('/viewAllRequirements', {
      templateUrl: 'static/views/viewAllRequirements.html',
      
    }).when('/searchRequirement', {
      templateUrl: 'static/views/searchRequirement.html',
      
    }).
    otherwise({
      redirectTo: 'index.jsp'
    });
  }
]);
