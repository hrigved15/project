'use strict'


var mainApp = angular.module("myApp", ['ngRoute']);
mainApp.config(['$routeProvider',
  function($routeProvider) {
    $routeProvider.
    when('/addStudent', {
      templateUrl: 'static/addStudent.html',
     
    }).
    when('/viewStudents', {
      templateUrl: 'static/viewStudents.html',
      
    }).
    otherwise({
      redirectTo: 'static/addStudent'
    });
  }
]);
mainApp.run( function ($rootScope) {
	   $rootScope.students =[{ name:'Abhishek', roll : 1},
							{name: 'Atul', roll:2}];
	});

var app = angular.module('myApp', []);





app.controller('myController',['$scope','UserService',function($scope,UserService) {
	
	alert('in controler...........');
	$scope.students1 =[{ name:'Abhishek', roll : 1},
							{name: 'Atul', roll:2}];
	$scope.requirement= {description:'',
			prerequisite:'',
			priority:'',
			shortTitle:'',
			status:'',
			title:'',
			type:'',
			version:'',
			attachments:[],
			elaborations:[],
			links:[]};
	
	fetchAllRequirements();

    function fetchAllRequirements(){
    	alert('Requirments fetched...');
    	
        UserService.fetchAllRequirements()
            .then(
            	
            function(d) {
            	alert(d);
              $scope.requirements = d;
            },
            function(errResponse){
                console.error('Error while fetching Users');
            }
        );
    }
    
	
	  $scope.addLink = function () {
	        $scope.requirement.links.push($scope.link);
	    };
	    $scope.addElaborations = function () {
	        $scope.requirement.elaborations.push($scope.elaboration);
	    };
	    $scope.addAttachments = function () {
	        $scope.requirement.attachments.push($scope.attachment);
	    };
	
	$scope.deleteRequirement= function()
	{
		alert("deleteRequirement controller");
		UserService.deleteRequirement($scope.requirement).then(fetchAllRequirements, function(reason) {
			console.error("failed to delete");
		})

	}

	$scope.createRequirement= function()
	{
		alert("create requirement controller ---"+$scope.requirement.links);
		UserService.createRequirement($scope.requirement).then(fetchAllRequirements, function(reason) {
			console.error("failed to create");
		})

	}
	

}])
