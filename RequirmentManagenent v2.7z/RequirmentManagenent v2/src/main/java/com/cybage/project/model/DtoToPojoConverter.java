package com.cybage.project.model;


import java.sql.Timestamp;
import java.util.Date;

import com.cybage.project.model.Attachment;
import com.cybage.project.model.Requirement;
import com.cybage.project.model.RequirementDTO;
import com.cybage.project.model.RequirementElaboration;
import com.cybage.project.model.RequirementLink;

public class DtoToPojoConverter {
	
	
	
	public DtoToPojoConverter() {
		
	}
	public Requirement toRequirement(RequirementDTO dto)
	{
		return new Requirement(new Timestamp(new Date().getTime()),"n",dto.getDescription(),
				new Timestamp(new Date().getTime()),1,
				dto.getPrerequisite(),dto.getPriority(),dto.getShortTitle(),dto.getStatus(),dto.getTitle(),
				dto.getType(),dto.getVersion());
	}
	public Attachment toAttachment(RequirementDTO dto)
	{
		return null;
		//return new Attachment(new Timestamp(new Date().getTime()),dto.getAttachment());
	}
	
	public RequirementElaboration toRequirementElaboration(RequirementDTO dto)
	{
		return null;
		//return new RequirementElaboration(new Timestamp(new Date().getTime()),dto.getElaboration());
	}
	
	public RequirementLink toRequirementLink(RequirementDTO dto)
	{
		return null;
		//return new RequirementLink(new Timestamp(new Date().getTime()),dto.getLinks());
	}
}
