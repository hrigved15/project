CREATE DATABASE  IF NOT EXISTS `requirement_management` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `requirement_management`;
-- MySQL dump 10.13  Distrib 5.6.13, for Win32 (x86)
--
-- Host: localhost    Database: requirement_management
-- ------------------------------------------------------
-- Server version	5.6.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `attachments`
--

DROP TABLE IF EXISTS `attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `attachments` (
  `attachmentId` int(11) NOT NULL AUTO_INCREMENT,
  `attachment` blob,
  `requirementId` int(11) DEFAULT NULL,
  `userid` int(11) DEFAULT NULL,
  `addingTime` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`attachmentId`),
  UNIQUE KEY `attachmentId_UNIQUE` (`attachmentId`),
  KEY `requirementId_idx` (`requirementId`),
  KEY `userId8_idx` (`userid`),
  CONSTRAINT `requirementId1` FOREIGN KEY (`requirementId`) REFERENCES `requirement` (`requirementId`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `userId8` FOREIGN KEY (`userid`) REFERENCES `users` (`userId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attachments`
--

LOCK TABLES `attachments` WRITE;
/*!40000 ALTER TABLE `attachments` DISABLE KEYS */;
INSERT INTO `attachments` VALUES (15,'',27,1,'2016-11-03 13:06:13'),(16,NULL,27,1,'2016-11-03 13:06:13'),(17,NULL,27,2,'2016-11-03 13:06:13'),(18,'',28,1,'2016-11-03 14:41:21'),(19,NULL,NULL,NULL,'2016-11-04 06:14:43'),(21,NULL,37,NULL,'2016-11-07 08:51:35'),(22,NULL,38,1,'2016-11-07 09:08:25'),(23,NULL,39,1,'2016-11-07 09:10:29'),(24,'',40,1,'2016-11-07 11:57:40'),(25,'',41,1,'2016-11-07 12:56:30'),(26,'',42,1,'2016-11-07 15:52:18'),(27,'',43,1,'2016-11-07 15:53:39'),(28,'',44,1,'2016-11-07 15:54:43'),(29,'',45,2,'2016-11-08 10:40:06');
/*!40000 ALTER TABLE `attachments` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-11-08 17:55:33
